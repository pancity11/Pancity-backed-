/**
 * api.js — drop this next to pancity.jsx / PancityDashboard.jsx
 *
 * Wannan shine tushen (base) don kiran backend din NestJS daga cikin
 * pancity.jsx (user app) da PancityDashboard.jsx (admin app), maimakon
 * amfani da mock arrays (transactions, users, stats, da sauransu).
 *
 * A CodeSandbox:
 *   - Idan backend din yana gudana a wani sandbox daban, canza API_BASE
 *     zuwa URL din wannan sandbox, misali:
 *     "https://<backend-sandbox-id>-3000.csb.app/api"
 *   - Idan duk biyu suna cikin sandbox daya (monorepo), API_BASE na iya
 *     zama "/api" kai tsaye idan an saita proxy, ko kuma a bar cikakken URL.
 */
const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:3000/api";

function getToken() {
  // Ka ajiye token a wani wuri mai dorewa (state/context) bayan login,
  // sannan ka wuce shi ga wannan function — misali daga wani AuthContext.
  return window.__PANCITY_TOKEN__ || null;
}

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(data?.message || `Request failed: ${res.status}`);
  }
  return data;
}

export const api = {
  // ---- Auth (user app) ----
  signup: (payload) => request("/auth/user/signup", { method: "POST", body: payload, auth: false }),
  login: (payload) => request("/auth/user/login", { method: "POST", body: payload, auth: false }),
  setPin: (pin) => request("/auth/user/pin", { method: "POST", body: { pin } }),
  verifyPin: (pin) => request("/auth/user/pin/verify", { method: "POST", body: { pin } }),

  // ---- Auth (admin dashboard) ----
  adminLogin: (payload) => request("/auth/admin/login", { method: "POST", body: payload, auth: false }),

  // ---- Wallet ----
  getMyWallet: () => request("/wallet/me"),
  getMyLedger: (page = 1) => request(`/wallet/me/ledger?page=${page}`),
  demoFundWallet: (amount) => request("/wallet/fund/demo-credit", { method: "POST", body: { amount } }),

  // ---- Transactions ----
  purchase: (payload) => request("/transactions/purchase", { method: "POST", body: payload }),
  getMyTransactions: (page = 1, filters = {}) => {
    const qs = new URLSearchParams({ page, ...filters }).toString();
    return request(`/transactions/me?${qs}`);
  },

  // ---- Plans (airtime/data/cable/electricity) ----
  getPlans: (category, provider) => {
    const qs = new URLSearchParams({ ...(category && { category }), ...(provider && { provider }) });
    return request(`/plans?${qs.toString()}`, { auth: false });
  },

  // ---- Admin: Users ----
  adminListUsers: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/users?${qs}`);
  },
  adminSetUserStatus: (id, status) =>
    request(`/users/${id}/status`, { method: "PATCH", body: { status } }),
  adminSetUserKyc: (id, kycStatus) =>
    request(`/users/${id}/kyc`, { method: "PATCH", body: { kycStatus } }),

  // ---- Admin: Transactions ----
  adminListTransactions: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/transactions?${qs}`);
  },

  // ---- Admin: Dashboard / Reports ----
  adminStats: () => request("/dashboard/stats"),
  adminRevenueSeries: (days = 14) => request(`/dashboard/revenue-series?days=${days}`),
  adminNetworkSales: () => request("/dashboard/network-sales"),

  // ---- Admin: Plans management ----
  adminListAllPlans: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/plans/admin?${qs}`);
  },
  adminCreatePlan: (payload) => request("/plans", { method: "POST", body: payload }),
  adminUpdatePlan: (id, payload) => request(`/plans/${id}`, { method: "PATCH", body: payload }),
  adminDeletePlan: (id) => request(`/plans/${id}`, { method: "DELETE" }),
};

/**
 * MISALIN AMFANI a cikin PancityDashboard.jsx — maimakon:
 *
 *   const [transactions] = useState(allTransactions); // mock array
 *
 * a yi:
 *
 *   const [transactions, setTransactions] = useState([]);
 *   const [loading, setLoading] = useState(true);
 *
 *   useEffect(() => {
 *     api.adminListTransactions({ page: 1, limit: 50 })
 *       .then((res) => setTransactions(res.items))
 *       .catch((err) => console.error(err))
 *       .finally(() => setLoading(false));
 *   }, []);
 *
 * Haka nan don `stats`, `revenueSeries`, `networkSales`, da `users` — kowanne
 * yana da irin wannan tsari: useState([]) ko useState(null) sannan useEffect
 * yayi fetch daga api.xxx() maimakon karanta mock array/const dinsu.
 */
