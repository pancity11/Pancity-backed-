# Pancity Backend (NestJS + MongoDB) — Core

Wannan shine bangaren farko (core) na backend na gaskiya wanda zai maye gurbin
mock data a cikin `pancity.jsx` (user app) da `PancityDashboard.jsx` (admin
dashboard). An gina shi da **NestJS** + **MongoDB (Mongoose)**.

## Abinda ke ciki yanzu (Phase 1 — Core)

- **Auth**: signup/login na user (JWT), login na admin (JWT), saita/tantance
  Transaction PIN.
- **Users**: profile na kai (me), jerin duk users (admin, tare da search/filter
  ta status/KYC/accountType), canza status (active/suspended), canza KYC.
- **Wallet**: duba balance, ledger/history, demo top-up endpoint (wurin da za a
  hada Paystack/Flutterwave gaba), admin manual credit, cikakken ledger na
  admin.
- **Transactions**: purchase endpoint guda daya wanda ke aiki don Airtime,
  Data, Cable, Electricity, Exam Pin, Airtime2Cash — yana tantance PIN,
  cire kudi daga wallet, yayi rikodin transaction (success/failed na gaske,
  ba mock ba). Jerin nawa (me) da na admin (duka, tare da filter/search).
- **Plans**: CRUD na admin don airtime/data/cable/electricity plans + endpoint
  na jama'a don duba plans available (wanda zai maye gurbin
  `dataProviders`/`airtimeProviders`/`initialNetworkPlans` mock a dashboard).
- **Dashboard/Reports**: `stats`, `revenue-series`, `network-sales` — duk ana
  lissafa su kai tsaye daga MongoDB (real aggregation), ba mock array ba —
  wannan yana maye gurbin `stats`, `revenueSeries`, `networkSales` mock a
  saman PancityDashboard.jsx.

## Abinda BAI shiga wannan phase ba tukuna (Phase 2, mataki na gaba)

Wadannan har yanzu suna cikin mock a cikin PancityDashboard.jsx, kuma za mu
mayar da su bayan wannan core ya tabbata yana aiki lafiya:

- Referrals (referrers, referralRecords, referralEarnings, referralSettings)
- Admin roles/permissions (admins, ADMIN_ROLES, PERMISSION_GROUPS)
- Login logs / Activity logs (loginLogs, activityLogs)
- Notifications (notificationHistory, scheduledNotifications)
- Airtime-to-Cash requests queue (airtimeToCashRequests, A2C rates)
- Community section

## Yadda za a gudanar dashi (CodeSandbox)

1. Ka je [mongodb.com/atlas](https://www.mongodb.com/atlas) ka kirkiri **free
   cluster** (M0). Ka samo connection string (misali
   `mongodb+srv://user:pass@cluster0.xxx.mongodb.net/pancity`).
2. A CodeSandbox, ka kirkiri sabon **Node.js sandbox** (ba "React" ba — wannan
   backend din daban yake, ba a hadashi da frontend a sandbox daya ba sai an
   san yadda za a raba ports).
3. Ka jibge duk files din wannan folder (`pancity-backend/`) cikin sandbox
   din, ko ka push zuwa GitHub sannan ka import repo din zuwa CodeSandbox.
4. A cikin sandbox, ka kirkiri file mai suna `.env` (ka kwafo abinda ke cikin
   `.env.example`) ka cusa ainihin `MONGODB_URI` da wani dogon random string a
   `JWT_SECRET`.
5. CodeSandbox zai yi `npm install` kai tsaye. Idan bai yi ba, ka bude
   Terminal ka rubuta:
   ```
   npm install
   npm run start:dev
   ```
6. Da zarar ya tashi, za ka ga a console: `Pancity backend running on port
   3000` da kuma sakon admin da aka seed (default: `admin` / `admin123` — ka
   canza wannan nan take ta hanyar `.env`).
7. CodeSandbox zai baka wani URL kamar
   `https://<sandbox-id>-3000.csb.app`. Duk API endpoints suna karkashin
   `/api`, misali:
   `https://<sandbox-id>-3000.csb.app/api/auth/admin/login`

## Yadda za a hada frontend (pancity.jsx / PancityDashboard.jsx)

Ka duba `FRONTEND_api.example.js` a wannan folder — wannan shine tsarin
`fetch` wrapper wanda zai maye gurbin duk mock arrays. Misali:

```js
import { api } from "./api";

// A maimakon: const [transactions] = useState(allTransactions);
const [transactions, setTransactions] = useState([]);
useEffect(() => {
  api.adminListTransactions({ page: 1, limit: 50 }).then((r) => setTransactions(r.items));
}, []);
```

Saita `REACT_APP_API_BASE` (ko canji irinsa dangane da yadda aka gina
frontend sandbox din) zuwa URL na backend din (mataki na 7 a sama) + `/api`.

## Cikakken jerin API endpoints (Phase 1)

| Method | Path | Wanda zai iya amfani |
|---|---|---|
| POST | /api/auth/user/signup | Kowa |
| POST | /api/auth/user/login | Kowa |
| POST | /api/auth/admin/login | Kowa (admin credentials) |
| POST | /api/auth/user/pin | User (logged in) |
| POST | /api/auth/user/pin/verify | User (logged in) |
| GET | /api/users/me | User |
| PATCH | /api/users/me | User |
| GET | /api/users | Admin |
| GET | /api/users/:id | Admin |
| PATCH | /api/users/:id/status | Admin |
| PATCH | /api/users/:id/kyc | Admin |
| GET | /api/wallet/me | User |
| GET | /api/wallet/me/ledger | User |
| POST | /api/wallet/fund/demo-credit | User (demo — maye gurbinsa da real gateway) |
| GET | /api/wallet/admin/ledger | Admin |
| POST | /api/wallet/admin/credit | Admin |
| POST | /api/transactions/purchase | User |
| GET | /api/transactions/me | User |
| GET | /api/transactions | Admin |
| GET | /api/transactions/:id | Admin |
| GET | /api/plans | Kowa |
| GET | /api/plans/admin | Admin |
| POST | /api/plans | Admin |
| PATCH | /api/plans/:id | Admin |
| DELETE | /api/plans/:id | Admin |
| GET | /api/dashboard/stats | Admin |
| GET | /api/dashboard/revenue-series | Admin |
| GET | /api/dashboard/network-sales | Admin |

## Phase 2 — yanzu an kammala (Karshe)

Wadannan da a baya ake cewa "mock ne har yanzu" yanzu duk ana amfani da ainihin backend:

- **Admin roles/permissions**: `/admin-management` — CRUD na admins, canza rawar admin (role), reset 2FA. Default permissions per role suna daidai da abinda dashboard yake nunawa.
- **Login logs / Activity logs**: `/security-logs/logins` da `/security-logs/activity` — ana yin rikodin kowane admin login (nasara/kasawa) da manyan ayyuka (kirkiro/cire admin) kai tsaye.
- **Notifications**: `/notifications` — Compose/Send/Schedule broadcast na gaske, adadin masu karba (recipients) ana lissafa su daga MongoDB na gaske (ba random ba), akwai lightweight in-process scheduler wanda ke aika sakonnin da aka shirya (scheduled) a lokacinsu.
- **Referrals**: `/referrals` — Settings, records, da stats duk na gaske. Sabon user da ya yi signup da referral code na wani, yana samun signup bonus kai tsaye, kuma referrer yana samun reward idan admin ya amince (`reward` endpoint yana cusa wallet na gaske).
- **Airtime2Cash queue**: yanzu wani nau'i ne na Transaction (`type: "airtime2cash"`) mai cikakken workflow (pending → processing → approved → paid/rejected) tare da history/audit trail na gaske ta `/transactions/:id/a2c-status`.
- **Admin wallet debit**: `/wallet/admin/debit` — yanzu ana aiki na gaske (a baya kawai credit ke aiki).
- **Real payment gateway (Paystack)**: `/wallet/fund/paystack/initialize` da `/wallet/webhook/paystack` — bukatar `PAYSTACK_SECRET_KEY` a `.env` (kyauta daga dashboard.paystack.com). Har yanzu akwai demo-credit don gwaji cikin sauri ba tare da saita Paystack ba.
- **Biometric/fingerprint purchase**: yanzu na gaske ne — bayan an shigar da PIN daidai sau daya, ana samun "quickAuthToken" (na tsawon minti 5) wanda fingerprint zai iya amfani dashi maimakon PIN, amma har yanzu ana tantancewa a backend a duk lokacin. Idan lokaci ya wuce minti 5, sai a sake shigar da PIN.

### Abinda ya rage (Phase 3 — karami, ba muhimmi kamar na baya ba):

- **Role permission template editor** (Permissions tab a Security Settings) — har yanzu local ne kawai; role-based default permissions suna aiki daidai lokacin kirkiro admin, amma editing template dinsu daga UI ba a tura zuwa backend ba tukuna.
- **Referral commission tracking** — muna bin diddigin signup/referrer bonus na gaske, amma "ongoing commission" akan yawan ciniki (transaction volume) ba a gina ba tukuna.
- **Airtime2Cash conversion rates settings** (Settings tab) — har yanzu local ne kawai.
- **Community section** — babu wannan feature a wannan dashboard (ba a same shi cikin ainihin app ba a wannan zagaye).



An tambaye ni in bawa admin ganin password/PIN na users **kai tsaye** (raw).
Ban yi wannan ba, domin haka ba amintacce ba ne — ko a ina, ko wanne app:
password da PIN ana **hash** su ta hanya guda kawai (one-way), don kada
komai — ko da admin ne — ya iya karanta ainihin darajarsu. Wannan shine
ma'auni na masana'antu (industry standard) don kariyar asusun kudi.

Maimakon haka, an baiwa admin:
- `hasPasswordSet` / `hasPinSet` — ganin ko an saita su, ba darajarsu ba.
- `PATCH /users/:id/reset-password` da `PATCH /users/:id/reset-pin` — admin
  na iya **saita sabon** password/PIN idan user ya rasa nasa (misali ta
  hanyar customer support), amma ba zai iya ganin tsohon ba. Wannan shine
  yadda manyan kamfanoni (banks, fintech) ke gudanar da wannan.

Wannan yana cikin `PancityDashboard.jsx` a Users profile modal — akwai
"Reset Password" da "Reset PIN" buttons wadanda ke bude wani form don shigar
da sabon daraja.

## Yanzu duka fayiloli guda uku suna magana da backend daya

- `pancity.jsx` (user app): signup, login, saita PIN, duba wallet balance,
  duba transactions, da yin purchase (Airtime/Data/Cable/Electricity/Exam
  Pin/Airtime2Cash) — duk ana kiran ainihin backend, ba simulation ba.
  PIN din transaction yanzu ana **tantance shi na gaske** ta backend (a baya,
  kowace PIN mai lamba 4 tana wucewa kai tsaye ba tare da tantancewa ba).
- `PancityDashboard.jsx` (admin app): Dashboard KPIs, Users, Transactions, da
  Reports duk suna karanta ainihin bayanai daga MongoDB, ba mock arrays ba.
- Duk biyu suna amfani da `REACT_APP_API_BASE` daya (saita shi ga URL na
  wannan backend a CodeSandbox environment variables na kowanne sandbox).

### Abinda ya rage (har yanzu placeholder/Phase 2):
- Fingerprint/biometric-authorized purchase (har yanzu local simulation ne —
  bukatar hanyar tantancewa ta daban akan backend don purchase ba tare da
  PIN ba).
- Referrals, Admin roles/permissions, Login/Activity logs, Notifications,
  Airtime-to-Cash queue, Community, Admin wallet debit — duk har yanzu mock
  ne, kamar yadda aka bayyana a baya.
- Real payment gateway don Fund Wallet (yanzu bank-transfer info ne kawai —
  bukatar Paystack/Flutterwave webhook don ainihin auto-credit).


## Phase 3 — yanzu an kammala

- **Role permission template editor**: `/role-templates` — kowace rawa (Super Admin, Finance Admin, da sauransu) tana da ainihin template a MongoDB. Editing matrix a Security Settings > Permissions yanzu yana ajiyewa na gaske, kuma sabon admin da aka kirkiro yana amfani da wannan template kai tsaye (ba hardcoded ba kuma).
- **Referral commission tracking**: `/referrals/commissions` — ana lissafa ainihin "transaction volume" na kowane referee a cikin windo na kwanaki (commissionDurationDays), a kuma lissafa commission bisa commissionRate. Admin na iya biyan commission ta hanyar `/referrals/:id/pay-commission` wanda ke cusa wallet na referrer na gaske.
- **Airtime2Cash conversion rates**: `/a2c-settings` — kowace network (MTN, Airtel, Glo, 9mobile) tana da rate na kanta a MongoDB, editable daga admin. `/a2c-settings/rates` bude ne ga kowa (user app yana amfani da shi wajen nuna adadin da za a biya kafin a tura request), kuma service-wide on/off toggle (`/a2c-settings/service-enabled`) yana aiki na gaske.
- Duk fayilolin biyu (`pancity.jsx` da `PancityDashboard.jsx`) yanzu suna amfani da wadannan real-time rates/settings maimakon hardcoded constants.

## Cikakken jerin API endpoints (Phase 2 & 3)

| Method | Path | Wanda zai iya amfani |
|---|---|---|
| GET/POST/PATCH/DELETE | /api/admin-management | Admin |
| PATCH | /api/admin-management/:id/2fa-reset | Admin |
| GET | /api/security-logs/logins | Admin |
| GET | /api/security-logs/activity | Admin |
| POST | /api/notifications | Admin |
| GET | /api/notifications/history | Admin |
| GET/DELETE | /api/notifications/scheduled | Admin |
| GET/PATCH | /api/referrals/settings | Admin |
| GET | /api/referrals/records | Admin |
| GET | /api/referrals/stats | Admin |
| PATCH | /api/referrals/:id/qualify | Admin |
| PATCH | /api/referrals/:id/reward | Admin |
| GET | /api/referrals/commissions | Admin |
| PATCH | /api/referrals/:id/pay-commission | Admin |
| PATCH | /api/transactions/:id/a2c-status | Admin |
| GET/PATCH | /api/role-templates | Admin |
| GET | /api/a2c-settings/rates | Kowa |
| GET | /api/a2c-settings | Kowa |
| PATCH | /api/a2c-settings/rates/:network | Admin |
| PATCH | /api/a2c-settings/service-enabled | Admin |
| POST | /api/wallet/admin/debit | Admin |
| POST | /api/wallet/fund/paystack/initialize | User |
| POST | /api/wallet/webhook/paystack | Paystack (public, signature-verified) |

## Sauran muhimman abubuwa game da tsaro (security)

- Wallet funding na yanzu (`/wallet/fund/demo-credit`) **demo ne kawai** —
  yana cusa kudi kai tsaye ba tare da tabbatar da biyan kudi na gaske ba.
  Kafin production, dole a hada real payment gateway (Paystack/Flutterwave)
  ta hanyar **webhook** (ba daga frontend kai tsaye ba), domin kar mutum ya iya
  cusa wa kansa kudi kyauta.
- Kowane purchase yana bukatar Transaction PIN — wannan an riga an tsara shi.
- `JWT_SECRET` da admin password na default dole a canza kafin a fitar da app
  din ga jama'a.
